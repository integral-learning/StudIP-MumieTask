<?php 
class MumieTask extends StudIPPlugin implements PortalPlugin {
    public function getPortalTemplate() {
        $factory = new Flexi_TemplateFactory($this->getPluginPath() . '/templates');
        $template = $factory->open('SagHalloWelt.php');
        $template->set_attribute('wer', 'Welt');
        return $template;
    }
}